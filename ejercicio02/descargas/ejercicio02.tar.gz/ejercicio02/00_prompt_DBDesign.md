Diseña una base de datos en PostgreSQL, tomando en consideración que más adelante se desarrollará un sistema web completo que administre usuarios registrados, implemente CRUD del modelo normalizado (en todas las tablas), maneje imágenes y conserve definiciones de conceptos asociadas a cada libro.

Partiendo de que todo libro tiene ISBN, título, autor, año de publicación, género, precio, stock, formato, imágenes y conceptos definidos por libro, identifica dependencias funcionales y multivaluadas.

- Un libro puede tener varios autores.
- Un libro puede pertenecer a varios géneros.
- Un libro puede definir muchos conceptos y un mismo concepto puede aparecer en distintos libros con definiciones diferentes.
- Un libro puede tener varias imágenes.
- Formato y categoría son catálogos independientes.
- Debe existir como máximo un administrador.

Crea el diseño de la base de datos en un archivo .sql dentro del directorio library/db y llámalo schema.sql.

1.- Utiliza la macro-arquitectura monolítica para el desarrollo del sistema.
2.- Utiliza el patrón de diseño MVC para la UI.
3.- Utiliza el enfoque de organización de código por módulos.