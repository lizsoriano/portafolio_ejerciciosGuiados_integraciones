# Guía de continuidad — Ejercicio Guiado 02 (léeme primero)

Este archivo es para otra sesión de Claude (u otra persona) que continúe
este trabajo desde cero. Léelo antes de tocar nada. Está en la raíz del
repositorio a propósito, para que sea lo primero que se vea.

## 1. Dónde estás parado

- Repositorio real de trabajo: `claude-eg02/integracion02` (esta carpeta).
  Es un repo Git independiente (`main`, sin remoto configurado más allá del
  que el usuario ya tenga).
- **Fuente de verdad de la aplicación: `apps/web-monolito/`.** Es una app
  Node.js/Express/EJS + PostgreSQL, monolítica, ya funcional.
- **`library/` es un borrador viejo duplicado. NO lo uses, NO lo edites, NO
  lo trates como si fuera la app real.** Contiene una copia antigua de
  `apps/web-monolito`, `data/`, `db/` y los prompts originales. Se
  mantiene solo por historial.
- `data/schema.sql` es el esquema PostgreSQL canónico original (11 tablas).
  `db/01_schema.sql` es una copia idéntica de ese mismo DDL, mantenida en
  sincronía manualmente — si uno cambia, el otro debe actualizarse igual.
- Hay otra carpeta hermana, `claude-eg02/portafolio/`, que es el sitio
  personal del usuario (HTML estático, portafolio de la materia). No tiene
  relación con este ejercicio salvo que ahí es donde eventualmente se
  publicará la evidencia final (ver sección 5).
- **Ojo con el directorio de trabajo real:** en algún momento de esta
  sesión el usuario trabajó por error en `C:\Users\rutil\Desktop\luxuryFinds`,
  que es un proyecto totalmente distinto (un catálogo de lujo, rama
  `redesign/editorial-catalog`). Si una sesión nueva aparece ahí, **no es
  este proyecto**; el proyecto correcto es el descrito arriba.

## 2. Qué se te va a pedir (el enunciado real)

Este es el "Ejercicio Guiado 02" de la materia **Integración de
Aplicaciones Computacionales** (Universidad de Monterrey, Dr. Raúl Morales
Salcedo): una app web monolítica en Node.js para gestionar una librería en
línea, con PostgreSQL, normalizada hasta 4FN, desplegada en GCP (CentOS
Stream 10) detrás de Apache/NGINX bajo el prefijo `/library`, y publicada
como evidencia en `https://ubiquitous.udem.edu/~<matricula>/ejercicio02/`.

El usuario pegó el enunciado oficial completo en el chat en algún punto de
esta conversación. **Si no lo tienes disponible, pídeselo de nuevo antes de
asumir requisitos** — no lo reconstruyas de memoria ni inventes puntos.
Restricciones ya confirmadas y no negociables del enunciado:

- Sin API REST/GraphQL/SOAP, sin JSON/XML como contrato con el navegador.
- Todo acceso a datos con `pg` y SQL parametrizado, nunca concatenado.
- Como máximo un Administrador, protegido también en la base de datos.
- Node debe escuchar solo en `127.0.0.1:3000`; se publica vía reverse
  proxy en `/library`.
- Nombres de archivo `db/` y `docs/` exigidos **exactamente** como en el
  enunciado (ver sección 3 — ya se respetaron).
- No inventar evidencia de GCP, capturas de `psql` o pruebas que no se
  ejecutaron realmente. Esto es una instrucción explícita del usuario y se
  ha respetado estrictamente en todo el trabajo hecho hasta ahora.

## 3. Qué ya está hecho (verificado, pero solo estáticamente — ver sección 4)

Checklist completo con estado real en
[`docs/PROGRESS.md`](docs/PROGRESS.md) — **léelo, es la fuente de verdad
del avance**, se ha mantenido actualizado en cada paso. Resumen:

**`db/` (orden de ejecución exacto pedido por el enunciado):**
`00_create_database.sql` → `01_schema.sql` → `02_seed_30_per_table.sql` →
`03_all_quieries_before_stored_procedures.sql` → `04_stored_procedures.sql`
→ `05_triggers.sql` → `06_views.sql`. Los siete existen, están completos y
se validaron estáticamente (balance de sintaxis SQL, y el seed se validó
con un script Node ad-hoc que confirma que todas las llaves foráneas por
clave natural resuelven, hay exactamente 1 administrador, exactamente 1
portada por libro, y 17 conceptos reutilizados entre libros con
definición distinta — el punto central de la 4FN).

**`docs/` nuevos:** `REQUIREMENTS.md`, `ENGINEERING_DECISIONS.md`,
`ARCHITECTURE_MONOLITHIC.png`, `DB_DESIGN_ER_4FN.png`,
`NORMALIZATION_4FN.xlsx`, `GCP_COMMANDS.md`, `INSTRUCCIONES_INSTANCIA_GCP.md`,
`PROGRESS.md`.

**`docs/` que ya existían y siguen vigentes (no se tocaron, ya cumplían):**
`SECURITY_REVIEW.md` (11 amenazas, mínimo pedido 8),
`TEST_PLAN.md` (22 casos, mínimo pedido 15, todos en estado `PENDING`
porque requieren PostgreSQL/navegador reales),
`ARCHITECTURAL_EVALUATION.md` (cubre la Tarea en Casa 2c),
`AI_PROMPT_HISTORY.md` / `AI_CHANGELOG.md` (cubren la Tarea en Casa 2e),
`PROMPT_MAESTRO_IA.md`.

**Código de la app:** se agregó soporte de `BASE_PATH` (variable de
entorno) en `apps/web-monolito/src/app.js` y en 12 vistas EJS, para que la
app funcione detrás de un reverse proxy con prefijo `/library` sin romper
nada en desarrollo local (`BASE_PATH` vacío = comportamiento idéntico al
de antes). Se verificó con `node --check`, compilación EJS de las 14
vistas tocadas, y `npm run check`.

## 4. Lo que NO se pudo hacer ni verificar (y por qué)

**No hay PostgreSQL, `psql` ni `docker` disponibles en este entorno de
trabajo.** Ningún script `db/` se ejecutó nunca contra una base real. Toda
la validación fue estática (sintaxis, balance de paréntesis, resolución de
claves por nombre en el seed). Si la siguiente sesión SÍ tiene acceso a un
PostgreSQL real (local, Docker, o la instancia GCP), lo primero que debería
hacer es correr los 7 scripts en orden y confirmar que no hay errores —
es muy probable que aparezcan detalles menores a ajustar en una primera
corrida real (nombres de constraint, algún `RAISE EXCEPTION` sin probar,
etc.), porque nunca se ejecutaron de verdad.

**`apps/web-monolito/src/modules/*/routes.js` NO invoca los `sp_*` de
`db/04_stored_procedures.sql` ni las vistas de `db/06_views.sql`.** La app
sigue usando sus transacciones parametrizadas originales (que ya
funcionaban y se decidió no tocar sin poder probarlas). Los procedimientos
y vistas existen, son correctos y cada uno documenta en un comentario a
qué ruta real equivale, pero **no están conectados**. El detalle completo
de esta decisión y cómo conectarlos si se requiere está en
`docs/ENGINEERING_DECISIONS.md`, entrada **ED-11**. Es probablemente lo
más importante que falta si se lee el enunciado de forma estricta (Parte
5, punto 14: "debe existir la interfaz web... sp, triggers y vistas").

**Nada de infraestructura real de GCP.** No se creó ninguna instancia, no
se ejecutó ningún comando `gcloud`, no hay reverse proxy real configurado,
no hay capturas de pantalla. `docs/GCP_COMMANDS.md` y
`docs/INSTRUCCIONES_INSTANCIA_GCP.md` son instrucciones listas para que el
usuario las ejecute él mismo — nunca se presentaron como si ya se
hubieran ejecutado.

**Nada de la Parte 10 del enunciado (publicación en `ubiquitous.udem.edu`)
se hizo.** Eso requiere acceso al servidor de la materia que esta sesión
nunca tuvo.

**No existe un "reporte técnico" único consolidado** (Parte 9, punto 21
del enunciado). Su contenido está repartido entre `REQUIREMENTS.md`,
`ENGINEERING_DECISIONS.md`, `ARCHITECTURAL_EVALUATION.md`,
`SECURITY_REVIEW.md`, `TEST_PLAN.md` y los diagramas. El usuario no lo
pidió como archivo aparte explícitamente; si lo pide, es armar un
documento que enlace/resuma los anteriores, no investigar nada nuevo.

## 5. Siguientes pasos razonables, en orden de impacto

1. Si hay acceso a PostgreSQL real: ejecutar `db/00` a `db/06` en orden y
   corregir lo que falle. Esto desbloquea TODO lo demás (pruebas del
   `TEST_PLAN.md`, capturas de `psql`, decidir si conectar ED-11).
2. Decidir si se conecta `routes.js` a los `sp_*`/vistas (ED-11) o se deja
   como está y se documenta la decisión como definitiva en el reporte.
3. Ejecutar `docs/GCP_COMMANDS.md` contra una cuenta GCP real del usuario
   (esto lo tiene que autorizar y correr él, con sus propias credenciales).
4. Seguir `docs/INSTRUCCIONES_INSTANCIA_GCP.md` para desplegar y verificar
   `/library`.
5. Llenar `docs/TEST_PLAN.md` con resultados reales (capturas, sin
   contraseñas ni cookies) en vez de `PENDING`.
6. Armar el sitio de evidencia en `claude-eg02/portafolio/` (o donde el
   usuario indique) y publicarlo en `ubiquitous.udem.edu`, con el
   `.tar.gz` del proyecto sin `.env`/`node_modules`/`uploads` reales.

## 6. Detalles del entorno que te van a ahorrar tiempo

- **PowerShell 5.1, no pwsh moderno**: no uses `&&`; usa `;` o líneas
  separadas. Los diagramas PNG (`docs/render-architecture.ps1`,
  `docs/render-er-4fn.ps1`, y el original `data/render-er.ps1`) se generan
  con `System.Drawing` puro vía PowerShell — no hay Graphviz ni librería
  externa instalada. Si necesitas regenerarlos o hacer uno nuevo, sigue
  ese mismo patrón.
- **Python de este entorno (`C:\msys64\ucrt64\bin\python.exe`) no tiene
  pip ni permite instalar paquetes directamente** (política
  "externally-managed", PEP 668). Para usar `openpyxl` (como se hizo para
  `NORMALIZATION_4FN.xlsx`) hubo que crear un venv:
  `python -m venv <ruta>` y usar `<ruta>/bin/python.exe -m pip install openpyxl`
  (nota: el venv creado en MSYS2 usa `bin/`, no `Scripts/`, aunque estés en
  Windows). Ese venv se creó en un directorio de scratchpad temporal de la
  sesión anterior y probablemente ya no exista — hay que recrearlo.
- **`bcrypt` (dependencia de `apps/web-monolito`) tiene un script de
  instalación nativo que un guardia de npm bloquea por defecto.** Si
  corres `npm ci` y ves "1 package has install scripts not yet covered by
  allowScripts", corre `npm approve-scripts bcrypt` y luego `npm rebuild
  bcrypt`. Esto NO debe dejar cambios de formato en `package.json` — si
  `npm approve-scripts` reformatea el archivo (le pasó a esta sesión, lo
  revirtió con `git restore`), revisa el diff antes de dar por bueno
  cualquier cambio ahí.
- **`apps/web-monolito/src/server.js` exige `SELECT 1` exitoso contra
  PostgreSQL antes de escuchar en el puerto** — no hay forma de levantar
  el servidor ni de probar nada por HTTP (ni siquiera archivos estáticos)
  sin una base de datos real accesible en `DATABASE_URL`.
- **Puede aparecer un `.git/index.lock` huérfano** en `integracion02/.git/`
  (pasó una vez en esta sesión, 0 bytes, sin proceso activo). Antes de
  asumir que un problema de git es real, verifica que no haya un proceso
  `git` corriendo y, si el lock está huérfano, bórralo.
- Los hashes `bcrypt` usados en `db/02_seed_30_per_table.sql` corresponden
  a contraseñas de prueba documentadas en el propio script SQL
  (`AdminSeed2026!` para el administrador, `UsuarioSeed2026!` para el
  resto) — generados y verificados de verdad con `bcrypt.hash` +
  `bcrypt.compare`, no inventados a mano.

## 7. Reglas que el usuario ha marcado como importantes (no las rompas)

- `apps/web-monolito/` es la app real; `library/` nunca se toca.
- Reutilizar `data/schema.sql` y la documentación existente en vez de
  reinventar cuando ya hay algo válido.
- Scripts SQL compatibles con PostgreSQL (13+ usado como referencia por
  `GENERATED ALWAYS AS IDENTITY` e índices parciales).
- Nunca reportar como hecha una prueba o evidencia de GCP que no se haya
  ejecutado realmente. Ante la duda, marcar `PENDING` y explicar por qué.
- No `git push`. Los commits locales sí están permitidos si el usuario los
  pide explícitamente (como en esta sesión).
- No detenerse a preguntar entre cada archivo del plan; avanzar y dejar
  todo documentado en `docs/PROGRESS.md` al final de cada bloque de
  trabajo.
