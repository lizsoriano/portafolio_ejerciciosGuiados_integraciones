# Biblioteca web monolítica

Aplicación Node.js con HTML renderizado en servidor (Express + EJS), acceso directo a PostgreSQL y organización MVC por módulos. No expone APIs ni usa JSON/XML para intercambiar datos con el navegador.

## Modelo y normalización

Se usa `../../data/schema.sql` como esquema canónico (el enunciado menciona `db_schema.sql`, nombre que no existe en el repositorio). Las dependencias funcionales principales son `ISBN → título, año, precio, stock, formato, categoría` y las claves de cada catálogo determinan sus atributos. Las dependencias multivaluadas independientes `libro →→ autor`, `libro →→ género` y `libro →→ imagen` se resuelven con `book_authors`, `book_genres` y `book_images`. En `book_concepts`, la clave `(libro, concepto) → definición`: un mismo concepto puede tener una definición distinta en cada libro. El índice parcial de `users` garantiza como máximo un administrador.

## Despliegue en CentOS Stream 10

Requisitos: PostgreSQL en ejecución, usuario `library_user`, contraseña `library666`, base `library_db`, y Node.js 20 o posterior. Ejecute desde la raíz del repositorio:

```bash
sudo dnf install -y nodejs npm
PGPASSWORD=library666 psql -h localhost -U library_user -d library_db -f data/schema.sql
cd apps/web-monolito
npm ci
cp .env.example .env
chmod 600 .env
```

Edite `.env`: reemplace `SESSION_SECRET` por una cadena aleatoria (por ejemplo, `openssl rand -hex 32`) y cambie la contraseña inicial del administrador. Créelo una vez:

```bash
node scripts/create-admin.js
npm start
```

La aplicación escucha en `http://localhost:3000`. Para ejecutarla como servicio, cree `/etc/systemd/system/library-web.service`:

```ini
[Unit]
Description=Biblioteca web monolítica
After=network.target postgresql.service

[Service]
Type=simple
User=library
Group=library
WorkingDirectory=/opt/library/apps/web-monolito
EnvironmentFile=/opt/library/apps/web-monolito/.env
ExecStart=/usr/bin/node src/server.js
Restart=on-failure
PrivateTmp=true
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
```

Ajuste usuario y ruta a su instalación, dé a ese usuario escritura sobre `public/uploads`, y active el servicio:

```bash
sudo chown -R library:library /opt/library/apps/web-monolito/public/uploads
sudo systemctl daemon-reload
sudo systemctl enable --now library-web
sudo systemctl status library-web
```

En producción coloque Nginx o Apache delante de `127.0.0.1:3000`, habilite HTTPS y mantenga `NODE_ENV=production` para que la cookie de sesión solo viaje por HTTPS.

## Desarrollo

```bash
cp .env.example .env
npm install
npm run dev
```

Todas las operaciones de escritura requieren administrador. Los usuarios activos pueden consultar el catálogo. Los formularios usan CSRF, las contraseñas se guardan con bcrypt, las sesiones viven en PostgreSQL y las imágenes aceptadas son JPEG, PNG, WebP o GIF de hasta 5 MB.
