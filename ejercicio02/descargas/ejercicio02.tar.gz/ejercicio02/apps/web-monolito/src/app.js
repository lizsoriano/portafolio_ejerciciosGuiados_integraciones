'use strict';
require('dotenv').config();const express=require('express'),session=require('express-session'),pgSession=require('connect-pg-simple')(session),helmet=require('helmet'),methodOverride=require('method-override'),path=require('path');const {pool}=require('./config/db');const csrf=require('./middleware/csrf');const {notFound,errorHandler}=require('./middleware/errors');
const app=express();app.set('view engine','ejs');app.set('views',path.join(__dirname,'views'));app.set('trust proxy',1);
// BASE_PATH permite publicar la app detras de un reverse proxy con prefijo
// (ej. /library, ver docs/INSTRUCCIONES_INSTANCIA_GCP.md). Vacio por
// defecto: no cambia nada del comportamiento actual en desarrollo.
const basePath=(process.env.BASE_PATH||'').replace(/\/+$/,'');
app.locals.basePath=basePath;
const router=express.Router();
router.use(helmet({contentSecurityPolicy:{directives:{"img-src":["'self'","data:"],"upgrade-insecure-requests":null}}}));router.use(express.urlencoded({extended:false,limit:'100kb'}));router.use(methodOverride('_method'));router.use(express.static(path.join(__dirname,'../public'),{maxAge:'1d'}));
router.use(session({store:new pgSession({pool,createTableIfMissing:true}),name:'library.sid',secret:process.env.SESSION_SECRET||'solo-desarrollo-cambie-esta-clave',resave:false,saveUninitialized:false,cookie:{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',maxAge:8*60*60*1000}}));
router.use((req,res,next)=>{req.flash=(type,message)=>{req.session.flash={type,message};};res.locals.user=req.session.user;res.locals.flash=req.session.flash;delete req.session.flash;
  // Reescribe los redirect() absolutos existentes en las rutas para que respeten basePath, sin tocar cada llamada.
  const originalRedirect=res.redirect.bind(res);
  res.redirect=(a,b)=>{const url=b===undefined?a:b;const status=b===undefined?undefined:a;const target=typeof url==='string'&&url.startsWith('/')?basePath+url:url;return status===undefined?originalRedirect(target):originalRedirect(status,target);};
  next();});router.use(csrf);
router.get('/',async(req,res)=>{const {rows}=await pool.query('SELECT b.book_id,b.title,b.price,(SELECT image_url FROM book_images WHERE book_id=b.book_id AND is_cover LIMIT 1) cover FROM books b ORDER BY created_at DESC LIMIT 8');res.render('home',{title:'Biblioteca',books:rows});});
router.use('/auth',require('./modules/auth/routes'));router.use('/books',require('./modules/books/routes'));router.use('/catalogs',require('./modules/catalogs/routes'));router.use('/manage',require('./modules/people/routes'));router.use('/users',require('./modules/users/routes'));router.use(notFound);router.use(errorHandler);
app.use(basePath,router);module.exports=app;
