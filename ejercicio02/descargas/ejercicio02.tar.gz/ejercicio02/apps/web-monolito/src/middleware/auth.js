'use strict';
function requireUser(req, res, next) {
  if (req.session.user) return next();
  req.session.returnTo = req.originalUrl; req.flash('error', 'Inicia sesión para continuar.'); res.redirect('/auth/login');
}
function requireAdmin(req, res, next) {
  if (req.session.user?.isAdmin) return next();
  req.flash('error', 'Se requieren permisos de administrador.'); res.redirect('/');
}
module.exports = { requireUser, requireAdmin };
