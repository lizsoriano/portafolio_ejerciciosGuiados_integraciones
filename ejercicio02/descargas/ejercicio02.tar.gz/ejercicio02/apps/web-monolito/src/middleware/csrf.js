'use strict';
const crypto = require('crypto');
function isValid(req) {
  const supplied = String(req.body?._csrf || req.query?._csrf || ''), expected = req.session.csrfToken || '';
  return supplied.length === expected.length && crypto.timingSafeEqual(Buffer.from(supplied), Buffer.from(expected));
}
function csrf(req, res, next) {
  if (!req.session.csrfToken) req.session.csrfToken = crypto.randomBytes(32).toString('hex');
  res.locals.csrfToken = req.session.csrfToken;
  // Los formularios multipart/form-data (subida de imagenes) llegan aqui sin
  // procesar: multer todavia no corrio, asi que req.body._csrf no existe aun.
  // Se valida manualmente despues de multer en la propia ruta (ver
  // modules/books/routes.js, POST /:id/images) usando csrf.isValid().
  if (req.is('multipart/form-data')) return next();
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method) && !isValid(req)) {
    return res.status(403).render('error', { title: 'Solicitud rechazada', message: 'El formulario expiró o no es válido.' });
  }
  next();
}
module.exports = csrf;
module.exports.isValid = isValid;
