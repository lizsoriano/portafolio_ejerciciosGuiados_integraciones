'use strict';
function notFound(req, res) { res.status(404).render('error', { title: 'No encontrado', message: 'La página solicitada no existe.' }); }
function errorHandler(error, req, res, next) {
  console.error(error); if (res.headersSent) return next(error);
  let message = 'Ocurrió un error inesperado.';
  if (error.code === '23505') message = 'Ya existe un registro con esos datos.';
  if (error.code === '23503') message = 'El registro está en uso y no puede eliminarse.';
  if (error.code === '23514' || error.code === '22P02') message = 'Los datos enviados no son válidos.';
  res.status(error.status || 500).render('error', { title: 'Error', message });
}
module.exports = { notFound, errorHandler };
