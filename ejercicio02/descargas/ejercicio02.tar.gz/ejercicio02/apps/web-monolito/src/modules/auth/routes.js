'use strict';
const express = require('express'), bcrypt = require('bcrypt');
const { pool } = require('../../config/db');
const router = express.Router();
router.get('/login', (req, res) => res.render('auth/login', { title: 'Iniciar sesión' }));
router.post('/login', async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const { rows } = await pool.query('SELECT user_id,email,password_hash,display_name,is_admin FROM users WHERE lower(email)=$1 AND is_active', [email]);
  const user = rows[0];
  if (!user || !(await bcrypt.compare(String(req.body.password || ''), user.password_hash))) {
    req.flash('error', 'Correo o contraseña incorrectos.'); return res.status(422).render('auth/login', { title: 'Iniciar sesión', email });
  }
  req.session.regenerate((error) => { if (error) throw error; req.session.user = { id: user.user_id, email: user.email, name: user.display_name, isAdmin: user.is_admin }; res.redirect('/'); });
});
router.post('/logout', (req, res, next) => req.session.destroy((error) => error ? next(error) : res.redirect('/auth/login')));
module.exports = router;
