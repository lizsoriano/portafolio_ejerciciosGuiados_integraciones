'use strict';
require('dotenv').config();const app=require('./app');const {pool}=require('./config/db');const port=Number(process.env.PORT)||3000;const host=process.env.HOST||'127.0.0.1';
if(!process.env.DATABASE_URL)throw new Error('Falta DATABASE_URL en el entorno.');if(!process.env.SESSION_SECRET)console.warn('ADVERTENCIA: configure SESSION_SECRET antes de producción.');
pool.query('SELECT 1').then(()=>app.listen(port,host,()=>console.log(`Biblioteca disponible en http://${host}:${port}`))).catch(e=>{console.error('No se pudo conectar con PostgreSQL:',e.message);process.exit(1);});
