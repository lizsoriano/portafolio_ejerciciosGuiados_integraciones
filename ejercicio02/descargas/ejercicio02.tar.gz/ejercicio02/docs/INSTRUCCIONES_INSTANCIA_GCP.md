# Instrucciones para sincronizar la instancia GCP con este repositorio

Este documento es **solo para ti**: pasos listos para copiar/pegar en tu
instancia real, para llevarla al mismo estado que este repositorio local
(nuevos scripts `db/00`–`db/06`, soporte de prefijo `/library` vía
`BASE_PATH`, y la documentación en `docs/`). No incluye IPs, usuarios ni
contraseñas reales — reemplaza cada `<marcador>` por tu valor real.

No se ejecutó nada de esto desde esta sesión de trabajo: no hay acceso a tu
instancia. Ejecuta cada bloque tú mismo, en el lugar indicado, y conserva la
salida como evidencia.

## 0. Dónde se ejecuta cada cosa

- **[LOCAL]** = en tu máquina, dentro de este repositorio.
- **[SSH]** = dentro de la instancia GCP, después de conectarte por SSH.

```bash
# [LOCAL] conectarte a la instancia
gcloud compute ssh <NOMBRE_INSTANCIA> --zone=<ZONA>
# o, si ya tienes la IP y una clave configurada:
ssh <usuario_ssh>@<IP_DEL_SERVIDOR>
```

## 1. Actualizar el código de la aplicación

Elige UNA de las dos formas, según cómo hayas desplegado originalmente.

### Opción A — con Git (recomendada si el repo ya está clonado en la instancia)

```bash
# [SSH]
cd /opt/library   # o la ruta donde clonaste el proyecto
git status        # revisa que no haya cambios locales sin commitear en el servidor
git pull origin main   # o la rama que hayas publicado
```

### Opción B — sin Git, copiando archivos desde tu máquina

```bash
# [LOCAL] — ajusta la ruta remota a donde vive el proyecto en la instancia
rsync -avz --exclude 'node_modules' --exclude '.env' --exclude 'public/uploads' \
  ./ <usuario_ssh>@<IP_DEL_SERVIDOR>:/opt/library/
```

### Instalar dependencias y verificar sintaxis

```bash
# [SSH]
cd /opt/library/apps/web-monolito
npm ci
npm run check
```

## 2. Aplicar los scripts SQL en el orden correcto

**Importante**: si la base de datos y el usuario `library_user` ya existen
de un despliegue anterior, **omite el paso 2.1** (falla si el rol/base ya
existen) y continúa directo con 2.2.

```bash
# [SSH] 2.1 — SOLO la primera vez, o si vas a recrear la base desde cero
sudo -u postgres psql -f /opt/library/db/00_create_database.sql

# [SSH] 2.2 — esquema (seguro de reintentar solo si la base está vacía;
# si ya tiene tablas, CREATE TABLE fallará por "ya existe": eso es
# esperado y significa que este paso ya se aplicó antes)
PGPASSWORD='<contraseña_library_user>' psql -h localhost -U library_user -d library_db \
  -f /opt/library/db/01_schema.sql

# [SSH] 2.3 — datos de prueba (usa ON CONFLICT solo donde corresponde;
# si ya sembraste datos antes, revisa antes de re-ejecutar para no duplicar)
PGPASSWORD='<contraseña_library_user>' psql -h localhost -U library_user -d library_db \
  -f /opt/library/db/02_seed_30_per_table.sql

# [SSH] 2.4 — consultas de referencia (de solo lectura, seguras de re-ejecutar)
PGPASSWORD='<contraseña_library_user>' psql -h localhost -U library_user -d library_db \
  -f /opt/library/db/03_all_quieries_before_stored_procedures.sql

# [SSH] 2.5 — procedimientos almacenados (CREATE OR REPLACE: seguro de re-ejecutar)
PGPASSWORD='<contraseña_library_user>' psql -h localhost -U library_user -d library_db \
  -f /opt/library/db/04_stored_procedures.sql

# [SSH] 2.6 — triggers (falla si ya existen; si es una actualización,
# elimina los triggers/funciones anteriores antes de re-ejecutar, o ejecuta
# solo la primera vez)
PGPASSWORD='<contraseña_library_user>' psql -h localhost -U library_user -d library_db \
  -f /opt/library/db/05_triggers.sql

# [SSH] 2.7 — vistas (CREATE OR REPLACE VIEW: seguro de re-ejecutar)
PGPASSWORD='<contraseña_library_user>' psql -h localhost -U library_user -d library_db \
  -f /opt/library/db/06_views.sql
```

Si 2.6 falla porque los triggers ya existen de una corrida previa, primero
elimínalos y vuelve a aplicar:

```sql
-- [SSH] dentro de: psql -h localhost -U library_user -d library_db
DROP TRIGGER IF EXISTS trg_authors_set_updated_at ON authors;
DROP TRIGGER IF EXISTS trg_users_set_updated_at ON users;
DROP TRIGGER IF EXISTS trg_books_set_updated_at ON books;
DROP TRIGGER IF EXISTS trg_book_concepts_set_updated_at ON book_concepts;
DROP TRIGGER IF EXISTS trg_book_images_single_cover ON book_images;
DROP TRIGGER IF EXISTS trg_users_last_admin_guard ON users;
\i /opt/library/db/05_triggers.sql
```

## 3. Configurar y activar el prefijo `/library`

Edita el archivo de entorno de la aplicación (`.env` o el
`EnvironmentFile` de systemd) y agrega:

```bash
# [SSH]
echo 'BASE_PATH=/library' | sudo tee -a /opt/library/apps/web-monolito/.env
```

## 3.1. Configuración del reverse proxy (`/library`)

Si aún no existe, crea el bloque de configuración de NGINX que publica la
app bajo `/library` y reenvía a Node en `127.0.0.1:3000`:

```nginx
# [SSH] /etc/nginx/conf.d/library.conf
location /library/ {
    proxy_pass http://127.0.0.1:3000/;
    proxy_http_version 1.1;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
}
```

O, si usas Apache en su lugar:

```apache
# [SSH] /etc/httpd/conf.d/library.conf
<Location "/library/">
    ProxyPass "http://127.0.0.1:3000/"
    ProxyPassReverse "http://127.0.0.1:3000/"
    RequestHeader set X-Forwarded-Proto "http"
</Location>
```

Con `BASE_PATH=/library` (paso 3) la aplicación ya genera enlaces,
formularios y redirecciones con el prefijo `/library` incluido, por lo que
`proxy_pass` reenvía tal cual, sin necesidad de reescribir el HTML de
salida (`sub_filter`) ni las rutas internas de Node.

## 4. Reiniciar los servicios

```bash
# [SSH] reiniciar la aplicación Node (si corre como servicio systemd)
sudo systemctl restart library-web
sudo systemctl status library-web --no-pager

# [SSH] recargar el reverse proxy después de cualquier cambio de configuración
sudo nginx -t && sudo systemctl reload nginx
# — o, si usas Apache —
sudo apachectl configtest && sudo systemctl reload httpd
```

## 5. Comprobar que PostgreSQL funciona

```bash
# [SSH]
sudo systemctl status postgresql --no-pager
pg_isready -h localhost -p 5432
PGPASSWORD='<contraseña_library_user>' psql -h localhost -U library_user -d library_db -c 'SELECT 1;'
```

Salida esperada: `accepting connections` en `pg_isready`, y una fila con
`1` en el `SELECT`.

## 6. Comprobar que Node/Express funciona

```bash
# [SSH]
curl -i http://127.0.0.1:3000/
sudo journalctl -u library-web -n 50 --no-pager
```

Salida esperada: `HTTP/1.1 200 OK` (o una redirección esperada) y sin
trazas de error en el log del servicio.

## 7. Comprobar HTTP a través del reverse proxy

```bash
# [SSH] primero desde dentro de la instancia
curl -i http://127.0.0.1/library/

# [LOCAL] luego desde afuera, como lo vería un usuario real
curl -i http://<IP_DEL_SERVIDOR>/library/
```

Verifica en el navegador, en una ventana privada/incógnito:
`http://<IP_DEL_SERVIDOR>/library/` — confirma que el login, el catálogo,
los formularios y las imágenes cargan con rutas que incluyen `/library`.

## 8. Verificar que cada cambio quedó aplicado

```sql
-- [SSH] dentro de: psql -h localhost -U library_user -d library_db

-- Conteo de filas por tabla (compara contra los valores esperados del seed:
-- ver el bloque de verificacion al final de db/02_seed_30_per_table.sql)
SELECT 'formats' t, count(*) FROM formats
UNION ALL SELECT 'books', count(*) FROM books
UNION ALL SELECT 'users', count(*) FROM users
ORDER BY 1;

-- Procedimientos, triggers y vistas presentes
\df sp_*
\dg+ library_user
SELECT tgname FROM pg_trigger WHERE NOT tgisinternal ORDER BY tgname;
\dv
```

```bash
# [SSH] variable BASE_PATH efectivamente cargada por el proceso
sudo systemctl show library-web -p Environment
```

Marca en tu propia copia de `docs/PROGRESS.md` (o en tu bitácora de
evidencia) la fecha y el resultado de cada verificación — esa evidencia,
generada por ti contra tu instancia real, es la que debe acompañar la
entrega, no una simulación.
