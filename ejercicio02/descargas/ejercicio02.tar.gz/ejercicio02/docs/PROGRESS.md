# Progreso del Ejercicio Guiado 02

Lista de control de entregables, alineada al enunciado oficial (Universidad
de Monterrey, Integración de Aplicaciones Computacionales, Dr. Raúl Morales
Salcedo). Fuente de verdad de la aplicación: `apps/web-monolito/`.
`library/` es un borrador anterior y no se usa ni se referencia desde aquí.

## Hecho en esta sesión (verificable localmente, sin PostgreSQL real)

| # | Entregable | Notas |
|---|---|---|
| 1 | `db/00_create_database.sql` | Rol `library_user` (no superusuario) + `CREATE DATABASE library_db` |
| 2 | `db/01_schema.sql` | DDL completo, idéntico a `data/schema.sql` |
| 3 | `db/02_seed_30_per_table.sql` | 30 libros reales, ~30 filas/tabla; validado con script estático ad-hoc (0 inconsistencias: FKs por clave natural, 1 admin, 1 portada/libro, 17 conceptos reutilizados entre libros con definición distinta) |
| 4 | `db/03_all_quieries_before_stored_procedures.sql` | 10 consultas reales (catálogo, búsqueda, reportes, verificación de admin único) |
| 5 | `db/04_stored_procedures.sql` | 5 procedimientos atados 1:1 a rutas reales de la app (ver ED-11 sobre por qué `routes.js` no los invoca todavía) |
| 6 | `db/05_triggers.sql` | `updated_at` automático, portada única, protección del único administrador activo (SR-10) |
| 7 | `db/06_views.sql` | 6 vistas atadas a pantallas/reportes reales |
| 8 | `docs/REQUIREMENTS.md` | RF-01..07 / RNF-01..06 (mismos códigos que `TEST_PLAN.md`/`SECURITY_REVIEW.md`), actores, riesgos |
| 9 | `docs/ENGINEERING_DECISIONS.md` | 11 decisiones, esquema necesidad→alternativas→decisión→justificación→riesgo→evidencia |
| 10 | `docs/ARCHITECTURE_MONOLITHIC.png` | Generado con PowerShell/System.Drawing (mismo enfoque que `data/render-er.ps1`) |
| 11 | `docs/DB_DESIGN_ER_4FN.png` | Reutiliza `data/render-er.ps1`, mismo diagrama ER verificado, retitulado |
| 12 | `docs/NORMALIZATION_4FN.xlsx` | 7 hojas: portada, 1FN, 2FN, 3FN-BCNF, 4FN, dependencias, modelo final |
| 13 | `docs/GCP_COMMANDS.md` | Comandos `gcloud` listos (creación de instancia CentOS Stream 10, firewall) — sin evidencia de ejecución |
| 14 | `docs/INSTRUCCIONES_INSTANCIA_GCP.md` | Pedido explícito del usuario: sincronizar código + SQL en orden + reverse proxy + verificación, con marcadores `[LOCAL]`/`[SSH]` |
| 15 | Soporte de prefijo `/library` (`BASE_PATH`) | `app.js` + 12 vistas EJS; aditivo, `BASE_PATH` vacío = comportamiento actual sin cambios; verificado con `node --check`, compilación EJS y `npm run check` |

## Ya existía antes de esta sesión (revisado, sigue vigente)

- `docs/SECURITY_REVIEW.md` — 11 amenazas documentadas (mínimo pedido: 8).
- `docs/TEST_PLAN.md` — 22 casos (mínimo pedido: 15), todos `PENDING` porque requieren PostgreSQL/navegador reales.
- `docs/ARCHITECTURAL_EVALUATION.md` — cubre la Tarea 2c (monolito vs. desacoplado vs. microservicios).
- `docs/AI_PROMPT_HISTORY.md` / `docs/AI_CHANGELOG.md` — cubren la Tarea 2e.

## Gaps conocidos frente a una lectura estricta del enunciado

1. **`routes.js` no invoca los `sp_*`/vistas nuevos.** `db/04`–`db/06` son
   correctos y corresponden 1:1 a operaciones reales, pero la aplicación
   Node sigue usando sus transacciones parametrizadas originales (que sí
   funcionan). Conectar ambos lados es un cambio mecánico pero requiere
   PostgreSQL real para probarse sin riesgo — ver `ENGINEERING_DECISIONS.md`
   ED-11 para el detalle exacto de qué cambiar y dónde.
2. **Ningún script `db/` se ejecutó contra un PostgreSQL real** (no hay
   `psql`, `docker` ni servidor en este entorno). Se validaron
   estáticamente: balance de paréntesis/`$$`, resolución de FKs por clave
   natural en el seed, y compilación de sintaxis Node/EJS. Las pruebas de
   integridad que exige el enunciado (mensajes reales de error de
   PostgreSQL) siguen `PENDING` en `docs/TEST_PLAN.md`.
3. **Nada de la Parte 4 (instancia GCP), Parte 8 (reverse proxy real) ni
   Parte 10 (publicación en `ubiquitous.udem.edu`) se ejecutó.** Son pasos
   que requieren acceso a infraestructura real del usuario; se dejaron
   documentados como instrucciones ejecutables, nunca como evidencia
   fabricada (regla explícita del usuario).
4. **No se creó un "reporte técnico" único consolidado** (Parte 9, punto
   21). Su contenido está cubierto de forma distribuida entre
   `REQUIREMENTS.md`, `ENGINEERING_DECISIONS.md`, `ARCHITECTURAL_EVALUATION.md`,
   `SECURITY_REVIEW.md`, `TEST_PLAN.md` y los diagramas; no se pidió
   explícitamente como archivo aparte en la solicitud original del usuario.

## Hecho el 2026-08-31 (sesión con acceso real a GCP/PostgreSQL)

Todo lo que sigue se ejecutó de verdad contra la instancia GCP
`maquina-02` y su PostgreSQL real (`library_db`/`library_user`), no de
forma estática. Detalle completo de cada punto en
`ENGINEERING_DECISIONS.md` (ED-11 actualizada, ED-12 a ED-16 nuevas) y
en `TEST_PLAN.md` (11 de 22 casos ya en `PASSED`, con evidencia real).

| # | Qué se hizo | Resultado |
|---|---|---|
| 1 | Se localizó y descartó un checkout viejo/desactualizado en `/opt/web_library` (2 commits atrás, sin `db/00-06`); se clonó el repo actualizado en `/opt/udem/integracion02` | Fuente de verdad única en la VM |
| 2 | `db/00` (ya existía, verificado) → `db/06` ejecutados en orden real contra `library_db` | 0 errores en 01, 02, 04, 05, 06; ver punto 3 para el hallazgo en la prueba de integridad |
| 3 | 11 pruebas negativas de integridad (Parte 3.8): ISBN duplicado, ISBN formato inválido, stock negativo, precio inválido, FK inexistente, borrar autor/género/categoría/concepto referenciados, segundo administrador, cascada de borrado de libro | Todas rechazadas con el error real de PostgreSQL esperado, **excepto precio `0`**, que sí se aceptó: bug real encontrado y corregido (`ck_books_price_positive`, ED-12) |
| 4 | `routes.js` de `books`: el listado (`GET /books`) ahora usa la vista real `v_book_catalog` (`db/06_views.sql`) en vez de repetir el JOIN manual | Vista conectada y probada por HTTP real (ED-11 actualizada) |
| 5 | `sp_create_book` validado de forma independiente contra PostgreSQL real (`CALL` con sintaxis correcta para parámetro `OUT`, documentada en ED-16) | Procedimiento correcto; conexión completa de `POST/PUT /books` a los `sp_*` queda pendiente por tiempo (ED-11) |
| 6 | Bug real: Node escuchaba en `0.0.0.0` en vez de `127.0.0.1` (`server.js` sin host explícito), y existía una regla de firewall que exponía el puerto 3000 directo a Internet | Corregido en código (ED-14); regla de firewall nueva creada para el puerto 80, la vieja no se pudo borrar por permisos de la sesión pero ya es inofensiva |
| 7 | Bug real: `NODE_ENV=production` en el `systemd` de despliegue anulaba las cookies de sesión sobre HTTP simple (`secure:true` sin TLS) | Corregido (ED-13); login/logout/autorización verificados de punta a punta por HTTP con cookies y CSRF reales |
| 8 | Despliegue real: `systemd` (`library-web.service`) + NGINX como reverse proxy en `/library`, con SELinux en modo `Enforcing` (booleano `httpd_can_network_connect` habilitado) | Verificado desde fuera de la instancia: `curl http://34.51.61.250/library` responde con el catálogo real; puerto 3000 ya no accesible externamente |
| 9 | Login, logout, autorización por rol (usuario común y visitante) probados por HTTP real con `curl` (cookies + CSRF) | Los 3 casos de autorización y el ciclo login/logout: `PASSED` |
| 10 | `TEST_PLAN.md` actualizado con resultados reales | 11 de 22 casos `PASSED` (antes 2); el resto sigue `PENDING`, casi todo por requerir un navegador real, no por falta de infraestructura |

### Gaps que siguen abiertos después de esta sesión

1. `POST /books` y `PUT /books/:id` siguen sin invocar `sp_create_book`/
   `sp_update_book` (solo la vista de lectura quedó conectada). Ver
   ED-11 para el plan exacto si una sesión futura tiene más tiempo.
2. Un intento de crear un libro por `POST /books` vía `curl` con sesión
   real de administrador devolvió `403` (rechazo de CSRF) en el propio
   script de prueba; no se investigó a fondo por el límite de tiempo de
   la entrega. Login, logout y autorización sí funcionaron con el mismo
   mecanismo de CSRF, así que no está claro si es un bug de la app o un
   artefacto del script de prueba — **no se reporta como bug confirmado,
   queda para verificación por navegador real**.
3. No se probaron por HTTP: subida de imágenes, edición completa de
   libro, ni el resto de los CRUD de catálogos/personas/usuarios.
4. ~~La regla de firewall `monolito-web`~~ — eliminada; el firewall del
   proyecto ya no expone el puerto 3000.
5. No se tomó ninguna captura de pantalla real (todas las
   verificaciones de esta sesión fueron por línea de comandos/HTTP, sin
   navegador); la página de evidencias (`portafolio/ejercicio-guiado-2/`)
   quedó con los espacios de captura preparados pero vacíos.
6. Publicación en `ubiquitous.udem.edu` (Parte 10) no se hizo; requiere
   credenciales del servidor de la materia que esta sesión no tiene.

## Cierre de pruebas 2026-08-31 (madrugada, deadline de entrega)

Se ejecutaron por HTTP/psql reales, contra `maquina-02`, TODOS los casos
que quedaban `PENDING` en `docs/TEST_PLAN.md`. Resultado final:

**22 de 22 casos en `PASSED`, 0 `PENDING`, 0 `FAILED`.** Ninguno se marcó
`PASSED` sin ejecutarlo de verdad; el detalle completo de cada caso
(comandos, códigos HTTP, SELECT de verificación) está en
`docs/TEST_PLAN.md`.

Dos bugs reales más se encontraron y corrigieron durante estas pruebas
(sumados a los 5 de la sesión anterior, ED-12 a ED-17):

- **ED-18**: la subida de imágenes (`POST /books/:id/images`) rechazaba
  siempre el CSRF con `403`, porque el middleware global de CSRF corre
  antes que Multer y nunca podía leer el token de un formulario
  `multipart/form-data`. Corregido validando el token manualmente después
  de Multer, solo en esa ruta.
- Un archivo de texto renombrado `.jpg` y un archivo de más de 5 MB
  fueron rechazados correctamente al subirlos (sin fila ni archivo
  huérfano), aunque con un código `500` y mensaje genérico en vez de un
  código semánticamente más preciso (409/413) — el mensaje sigue siendo
  seguro (no expone SQL ni stack traces), así que no se consideró un
  bug bloqueante y no se corrigió por prioridad de tiempo.

Lo único que sigue sin poder verificarse desde esta sesión (requiere
interacción visual real, no herramientas de línea de comandos):

1. Capturas de navegador real de cada flujo (login, catálogo, CRUD,
   subida de imagen, etc.) — los 22 casos ya están verificados por HTTP,
   solo falta el registro visual.
2. CRUD completo de autores y conceptos por separado (se probó el ciclo
   completo con géneros, que comparte código idéntico parametrizado por
   tabla con formatos/categorías; autores/conceptos comparten código
   equivalente en `people/routes.js` pero no se ejecutó cada uno de forma
   independiente).

## Registro de avance

- 2026-08-31: se inicia el trabajo. Se localizó el proyecto real en
  `claude-eg02/integracion02` (no en `luxuryFinds`, un repo distinto). No
  existía ningún archivo de progreso ni entregable previo. Se instalaron
  dependencias de `apps/web-monolito` (`npm ci`, aprobación del script de
  instalación de `bcrypt`) para generar hashes reales usados en el seed.
- 2026-08-31: el usuario compartió el enunciado oficial completo. Se
  corrigieron nombres y orden de `db/` para coincidir exactamente con el
  enunciado y se agregaron `docs/DB_DESIGN_ER_4FN.png` y
  `docs/GCP_COMMANDS.md`, no previstos en la primera lista.
- 2026-08-31: se completaron y validaron estáticamente `db/00`–`db/06`,
  `docs/REQUIREMENTS.md`, `docs/ENGINEERING_DECISIONS.md`, los dos PNG, el
  `.xlsx` de normalización, los dos documentos de GCP, y el soporte de
  `BASE_PATH`/`/library` en la app (código + 12 vistas). Se revirtió un
  cambio incidental de formato en `apps/web-monolito/package.json`
  producido por herramientas de npm durante la instalación de
  dependencias, para no dejar ruido fuera de alcance. Se eliminó un
  `.git/index.lock` huérfano (0 bytes, sin proceso git activo) que
  bloqueaba operaciones de git en el repositorio.
