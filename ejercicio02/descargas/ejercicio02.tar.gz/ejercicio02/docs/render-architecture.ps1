Add-Type -AssemblyName System.Drawing

$width = 1900
$height = 1300
$bitmap = [System.Drawing.Bitmap]::new($width, $height)
$g = [System.Drawing.Graphics]::FromImage($bitmap)
$g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
$g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit
$g.Clear([System.Drawing.Color]::FromArgb(248, 250, 252))

$titleFont = [System.Drawing.Font]::new('Segoe UI', 26, [System.Drawing.FontStyle]::Bold)
$subFont = [System.Drawing.Font]::new('Segoe UI', 13)
$boxTitleFont = [System.Drawing.Font]::new('Segoe UI', 15, [System.Drawing.FontStyle]::Bold)
$boxTextFont = [System.Drawing.Font]::new('Segoe UI', 11)
$smallFont = [System.Drawing.Font]::new('Segoe UI', 10, [System.Drawing.FontStyle]::Italic)
$arrowFont = [System.Drawing.Font]::new('Segoe UI', 11, [System.Drawing.FontStyle]::Bold)

$textBrush = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::FromArgb(15, 23, 42))
$mutedBrush = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::FromArgb(71, 85, 105))
$whiteBrush = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::White)
$monolithBrush = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::FromArgb(238, 242, 255))
$headerBrush = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::FromArgb(30, 64, 175))
$moduleBrush = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::White)
$dbBrush = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::FromArgb(4, 120, 87))
$proxyBrush = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::FromArgb(180, 83, 9))
$borderPen = [System.Drawing.Pen]::new([System.Drawing.Color]::FromArgb(100, 116, 139), 2)
$monolithBorderPen = [System.Drawing.Pen]::new([System.Drawing.Color]::FromArgb(30, 64, 175), 3)
$arrowPen = [System.Drawing.Pen]::new([System.Drawing.Color]::FromArgb(51, 65, 85), 3)
$arrowPen.EndCap = [System.Drawing.Drawing2D.LineCap]::ArrowAnchor

$g.DrawString('Macro-arquitectura monolitica - Biblioteca en linea', $titleFont, $textBrush, 50, 25)
$g.DrawString('Navegador -> Apache/NGINX (reverse proxy /library) -> Node.js/Express (monolito) -> PostgreSQL', $subFont, $mutedBrush, 54, 65)

function Box($x, $y, $w, $h, $fill, $border, $title, $titleFont, $titleBrush, $lines, $textFont, $textBrush) {
    $g.FillRectangle($fill, $x, $y, $w, $h)
    $g.DrawRectangle($border, $x, $y, $w, $h)
    $g.DrawString($title, $titleFont, $titleBrush, $x + 12, $y + 8)
    $ly = $y + 34
    foreach ($line in $lines) {
        $g.DrawString($line, $textFont, $textBrush, $x + 12, $ly)
        $ly += 18
    }
}

function Arrow($x1, $y1, $x2, $y2, $label) {
    $g.DrawLine($arrowPen, $x1, $y1, $x2, $y2)
    if ($label) {
        $mx = ($x1 + $x2) / 2
        $my = ($y1 + $y2) / 2
        $size = $g.MeasureString($label, $arrowFont)
        $g.FillRectangle($whiteBrush, $mx - $size.Width / 2 - 4, $my - $size.Height / 2, $size.Width + 8, $size.Height)
        $g.DrawString($label, $arrowFont, $textBrush, $mx - $size.Width / 2, $my - $size.Height / 2)
    }
}

# --- Navegador ---
Box 60 120 260 90 $whiteBrush $borderPen 'Navegador' $boxTitleFont $textBrush @('HTML renderizado en servidor', 'formularios, cookies de sesion') $boxTextFont $mutedBrush

# --- Reverse proxy ---
Box 60 260 260 100 $whiteBrush $proxyBrush 'Apache / NGINX' $boxTitleFont $textBrush @('Publica /library', 'Termina TLS, reenvia a', '127.0.0.1:3000') $boxTextFont $mutedBrush

Arrow 190 210 190 260 'HTTP(S)'

# --- Monolito ---
$monoX = 460; $monoY = 120; $monoW = 960; $monoH = 900
$g.FillRectangle($monolithBrush, $monoX, $monoY, $monoW, $monoH)
$g.DrawRectangle($monolithBorderPen, $monoX, $monoY, $monoW, $monoH)
$g.DrawString('Aplicacion Node.js/Express (una sola unidad desplegable)', $boxTitleFont, $headerBrush.Color -as [System.Drawing.SolidBrush], $monoX + 16, $monoY + 12)
$g.DrawString('src/app.js: inicializa Express, monta middleware y rutas, arranca el servidor', $smallFont, $mutedBrush, $monoX + 16, $monoY + 40)

Arrow 320 305 460 305 'proxy_pass :3000'

$colX = $monoX + 30
$col1 = $colX
$col2 = $colX + 330
$col3 = $colX + 660

Box $col1 200 300 110 $moduleBrush $borderPen 'Middleware' $boxTextFont $textBrush @('helmet, session (pg),', 'CSRF, requireUser/', 'requireAdmin, errors') $boxTextFont $mutedBrush

Box $col2 200 300 110 $moduleBrush $borderPen 'Rutas / controladores' $boxTextFont $textBrush @('src/modules/{auth,books,', 'catalogs,people,users}', 'reciben HTTP, coordinan') $boxTextFont $mutedBrush

Box $col3 200 300 110 $moduleBrush $borderPen 'Vistas (EJS)' $boxTextFont $textBrush @('src/views/**', 'sin SQL ni logica de', 'negocio compleja') $boxTextFont $mutedBrush

Box $col1 340 300 110 $moduleBrush $borderPen 'Logica de negocio' $boxTextFont $textBrush @('validaciones, upsert de', 'conceptos, portada unica,', 'transaction() atomica') $boxTextFont $mutedBrush

Box $col2 340 300 110 $moduleBrush $borderPen 'Acceso a datos' $boxTextFont $textBrush @('src/config/db.js (pool pg)', 'SQL parametrizado $1..$n', 'llama sp_* de db/04') $boxTextFont $mutedBrush

Box $col3 340 300 110 $moduleBrush $borderPen 'Archivos estaticos / uploads' $boxTextFont $textBrush @('public/css, public/uploads', 'multer: tipo, tamano,', 'nombre generado') $boxTextFont $mutedBrush

Arrow ($col1+150) 310 ($col1+150) 340
Arrow ($col2+150) 310 ($col2+150) 340
Arrow ($col1+300) 255 ($col2) 255
Arrow ($col2+300) 255 ($col3) 255
Arrow ($col2+150) 340 ($col3+150) 340

Box $colX 500 990 140 $moduleBrush $borderPen 'Organizacion por modulos (MVC server-side)' $boxTextFont $textBrush @(
    'config/  -> conexion y configuracion de PostgreSQL',
    'modules/{auth,books,catalogs,people,users}/routes.js -> "controlador" (ruta + logica + acceso a datos)',
    'modules/**/views/*.ejs -> "vista"; books/genres/authors/concepts/users -> "modelo" (tablas de db/01_schema.sql)',
    'middleware/ -> autenticacion, autorizacion, CSRF, errores; transversal a todos los modulos'
) $boxTextFont $mutedBrush

Box $colX 670 990 260 $moduleBrush $borderPen 'Por que sigue siendo un monolito aunque el codigo este en modulos' $boxTextFont $textBrush @(
    '- Un solo proceso Node y un solo despliegue: no hay limites de red entre "auth", "books", "users", etc.',
    '- Los modulos comparten el mismo pool de conexion (config/db.js) y la misma transaccion cuando corresponde.',
    '- No existe contrato de API entre modulos: se llaman como funciones/routers de Express en memoria.',
    '- La organizacion por carpetas es solo separacion de responsabilidades (MVC server-side), no separacion de despliegue.',
    '- Escalar significa replicar el proceso completo (todas las rutas), no un modulo de forma independiente.'
) $boxTextFont $mutedBrush

Box $colX 950 990 50 $whiteBrush $borderPen '' $boxTextFont $textBrush @('Sesion persistida en PostgreSQL (connect-pg-simple): no hay estado en memoria del proceso.') $smallFont $mutedBrush

# --- PostgreSQL ---
Box 1520 260 320 200 $whiteBrush $dbBrush 'PostgreSQL (library_db)' $boxTitleFont $textBrush @(
    'Tablas: db/01_schema.sql',
    'sp_*: db/04_stored_procedures.sql',
    'triggers: db/05_triggers.sql',
    'vistas: db/06_views.sql',
    'usuario library_user (no superusuario)'
) $boxTextFont $mutedBrush

Arrow ($col2+300) 255 1440 255
Arrow 1440 255 1520 300
$g.DrawString('SQL parametrizado (pg)', $arrowFont, $textBrush, 1300, 225)

Box 1520 500 320 120 $whiteBrush $borderPen 'Almacenamiento local' $boxTitleFont $textBrush @('public/uploads/', 'referenciado desde', 'book_images.image_url') $boxTextFont $mutedBrush

Arrow ($col3+300) 425 1440 425
Arrow 1440 425 1520 555 'multipart/form-data'

$legendY = 1230
$g.DrawString('Leyenda:', $arrowFont, $textBrush, 60, $legendY)
$g.DrawString('Recuadro azul = frontera de la unidad desplegable (el monolito). Todo lo interno corre en el mismo proceso Node.', $smallFont, $mutedBrush, 160, $legendY)

$outputPath = Join-Path $PSScriptRoot 'ARCHITECTURE_MONOLITHIC.png'
$bitmap.Save($outputPath, [System.Drawing.Imaging.ImageFormat]::Png)

$g.Dispose(); $bitmap.Dispose()
Write-Output $outputPath
