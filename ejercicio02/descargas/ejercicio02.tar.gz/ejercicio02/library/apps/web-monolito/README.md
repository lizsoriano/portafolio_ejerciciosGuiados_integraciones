# Biblioteca Lumen — monolito Node.js

Aplicación web monolítica con Express, EJS y acceso directo a PostgreSQL. Renderiza todo el HTML en el servidor; no expone APIs ni usa JSON/XML para intercambiar datos. Incluye catálogo público, registro e inicio de sesión, carga de imágenes y CRUD administrativo de las 11 tablas del modelo.

## Modelo y dependencias

La clave candidata natural de un libro es `ISBN`. Sus dependencias funcionales son `ISBN → título, año_publicación, precio, stock, formato, categoría`. `Formato` y `categoría` son catálogos independientes. Las dependencias multivaluadas `ISBN →→ autor`, `ISBN →→ género`, `ISBN →→ imagen` y `ISBN →→ concepto` se separan en tablas de relación. En `book_concepts`, la definición depende de la clave compuesta `(libro, concepto)`, lo que permite definiciones distintas del mismo concepto en libros diferentes. Un índice único parcial garantiza como máximo un usuario administrador.

La aplicación organiza cada dominio como módulo y aplica MVC: las consultas PostgreSQL constituyen la capa de modelo, los archivos `routes.js` coordinan controladores y las plantillas EJS son las vistas.

## Despliegue en CentOS Stream 10

### 1. Preparar PostgreSQL

Desde la raíz del repositorio:

```bash
sudo -u postgres psql <<'SQL'
CREATE USER library_user WITH PASSWORD 'library666';
CREATE DATABASE library_db OWNER library_user;
SQL

PGPASSWORD=library666 psql -h localhost -U library_user -d library_db -f data/db_schema.sql
```

El script es transaccional. Ejecútelo una sola vez sobre una base vacía.

### 2. Instalar y configurar la aplicación

Se requiere Node.js 20 o posterior. En la raíz del repositorio:

```bash
cd apps/web-monolito
npm install --omit=dev
cp .env.example .env
chmod 600 .env
```

Edite `.env` y cambie `SESSION_SECRET` por una cadena aleatoria extensa. Para generar una:

```bash
openssl rand -hex 32
```

Con PostgreSQL local, `DATABASE_URL` ya contiene el usuario, contraseña y base indicados. En producción detrás de HTTPS conserve `NODE_ENV=production`. Si PostgreSQL local no usa TLS, agregue `PGSSL=false`.

### 3. Crear el primer administrador

Registre una cuenta desde `/registrarse` y promuévala desde PostgreSQL:

```bash
PGPASSWORD=library666 psql -h localhost -U library_user -d library_db \
  -c "UPDATE users SET is_admin = true WHERE email = 'admin@ejemplo.com';"
```

La base impedirá promover a un segundo administrador. Después ingrese de nuevo para refrescar la sesión.

### 4. Servicio systemd

Copie el repositorio, por ejemplo, a `/opt/library`, y otorgue al usuario de servicio permiso de escritura solamente sobre `public/uploads`:

```bash
sudo useradd --system --home /opt/library --shell /sbin/nologin library-web
sudo chown -R root:root /opt/library
sudo chown -R library-web:library-web /opt/library/apps/web-monolito/public/uploads
```

Cree `/etc/systemd/system/library-web.service`:

```ini
[Unit]
Description=Biblioteca Lumen
After=network.target postgresql.service

[Service]
Type=simple
User=library-web
Group=library-web
WorkingDirectory=/opt/library/apps/web-monolito
EnvironmentFile=/opt/library/apps/web-monolito/.env
ExecStart=/usr/bin/node src/app.js
Restart=on-failure
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
```

Active el servicio:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now library-web
sudo systemctl status library-web
```

La aplicación escucha por defecto en `127.0.0.1:3000`. Configure Nginx o Apache como proxy inverso HTTPS hacia ese puerto. Asegure copias de respaldo tanto de `library_db` como de `public/uploads`.

## Desarrollo local

```bash
cd apps/web-monolito
cp .env.example .env
npm install
npm run dev
```

Abra `http://localhost:3000`. Para una comprobación rápida de sintaxis use `npm run check`.
