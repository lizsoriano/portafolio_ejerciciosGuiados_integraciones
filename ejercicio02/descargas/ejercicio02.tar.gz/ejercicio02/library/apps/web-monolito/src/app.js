require('dotenv').config();
const path = require('path');
const express = require('express');
const session = require('express-session');
const PgSession = require('connect-pg-simple')(session);
const helmet = require('helmet');
const methodOverride = require('method-override');
const db = require('./config/database');
const authRoutes = require('./modules/auth/routes');
const catalogRoutes = require('./modules/catalog/routes');
const adminRoutes = require('./modules/admin/routes');
const { requireLogin, requireAdmin } = require('./middleware/auth');

if (!process.env.DATABASE_URL || !process.env.SESSION_SECRET) {
  console.error('Faltan DATABASE_URL o SESSION_SECRET. Copie .env.example como .env.');
  process.exit(1);
}

const app = express();
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.urlencoded({ extended: false, limit: '1mb' }));
app.use(methodOverride('_method'));
app.use(express.static(path.join(__dirname, '../public'), { maxAge: process.env.NODE_ENV === 'production' ? '1d' : 0 }));
app.use(session({
  store: new PgSession({ pool: db, createTableIfMissing: true }),
  name: 'library.sid', secret: process.env.SESSION_SECRET, resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 1000 * 60 * 60 * 8 },
}));
app.use((req, res, next) => {
  res.locals.user = req.session.user;
  res.locals.flash = req.session.flash;
  delete req.session.flash;
  next();
});
app.use(authRoutes);
app.use('/admin', requireLogin, requireAdmin, adminRoutes);
app.use(catalogRoutes);
app.use((_req, res) => res.status(404).render('errors/error', { title: 'Página no encontrada', status: 404, message: 'La página solicitada no existe.' }));
app.use((error, req, res, _next) => {
  console.error(error);
  const message = error.code?.startsWith('23') ? 'La operación viola una regla de integridad. Revisa relaciones, duplicados y campos obligatorios.' : 'Ocurrió un error inesperado.';
  res.status(500).render('errors/error', { title: 'No se pudo completar', status: 500, message });
});

const port = Number(process.env.PORT || 3000);
const host = process.env.HOST || '127.0.0.1';
app.listen(port, host, () => console.log(`Biblioteca disponible en http://${host}:${port}`));
