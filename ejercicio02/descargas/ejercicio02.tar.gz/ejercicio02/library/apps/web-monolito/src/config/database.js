const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' && process.env.PGSSL !== 'false'
    ? { rejectUnauthorized: false }
    : false,
});

pool.on('error', (error) => console.error('Error inesperado de PostgreSQL:', error));
module.exports = pool;
