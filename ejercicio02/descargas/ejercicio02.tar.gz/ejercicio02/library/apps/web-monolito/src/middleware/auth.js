function requireLogin(req, res, next) {
  if (req.session.user) return next();
  req.session.returnTo = req.originalUrl;
  req.session.flash = { type: 'error', message: 'Inicia sesión para continuar.' };
  return res.redirect('/ingresar');
}

function requireAdmin(req, res, next) {
  if (req.session.user?.is_admin) return next();
  return res.status(403).render('errors/error', { title: 'Acceso denegado', status: 403, message: 'Esta sección requiere permisos de administrador.' });
}

module.exports = { requireLogin, requireAdmin };
