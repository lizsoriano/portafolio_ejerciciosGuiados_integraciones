module.exports = {
  formats: { label: 'Formatos', pk: ['format_id'], fields: { name: 'text', description: 'textarea' } },
  categories: { label: 'Categorías', pk: ['category_id'], fields: { name: 'text', description: 'textarea' } },
  genres: { label: 'Géneros', pk: ['genre_id'], fields: { name: 'text', description: 'textarea' } },
  authors: { label: 'Autores', pk: ['author_id'], fields: { first_name: 'text', last_name: 'text', biography: 'textarea' } },
  users: { label: 'Usuarios', pk: ['user_id'], fields: { email: 'email', display_name: 'text', password: 'password', is_admin: 'boolean', is_active: 'boolean' } },
  books: { label: 'Libros', pk: ['book_id'], fields: { isbn: 'text', title: 'text', publication_year: 'number', price: 'number', stock: 'number', format_id: 'number', category_id: 'number' } },
  concepts: { label: 'Conceptos', pk: ['concept_id'], fields: { name: 'text' } },
  book_authors: { label: 'Autores por libro', pk: ['book_id','author_id'], fields: { book_id: 'number', author_id: 'number', author_order: 'number' } },
  book_genres: { label: 'Géneros por libro', pk: ['book_id','genre_id'], fields: { book_id: 'number', genre_id: 'number' } },
  book_concepts: { label: 'Definiciones por libro', pk: ['book_id','concept_id'], fields: { book_id: 'number', concept_id: 'number', definition: 'textarea' } },
  book_images: { label: 'Imágenes por libro', pk: ['image_id'], fields: { book_id: 'number', image_url: 'text', alt_text: 'text', display_order: 'number', is_cover: 'boolean' } }
};
