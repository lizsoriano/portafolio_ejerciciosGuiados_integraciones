const express = require('express');
const path = require('path');
const crypto = require('crypto');
const multer = require('multer');
const bcrypt = require('bcryptjs');
const db = require('../../config/database');
const entities = require('./entities');

const router = express.Router();
const upload = multer({
  storage: multer.diskStorage({
    destination: path.join(__dirname, '../../../public/uploads'),
    filename: (_req, file, cb) => cb(null, `${crypto.randomUUID()}${path.extname(file.originalname).toLowerCase()}`),
  }),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => cb(null, ['image/jpeg','image/png','image/webp','image/gif'].includes(file.mimetype)),
});

function entity(req, res, next) {
  req.entity = entities[req.params.entity];
  if (!req.entity) return res.status(404).render('errors/error', { title: 'Módulo no encontrado', status: 404, message: 'La tabla solicitada no está habilitada.' });
  next();
}
function valuesFromBody(definition, body) {
  return Object.fromEntries(Object.entries(definition.fields).map(([name, type]) => [name, type === 'boolean' ? body[name] === 'on' : (body[name] === '' ? null : body[name])]));
}

router.get('/', (_req, res) => res.render('admin/dashboard', { title: 'Administración', entities }));
router.get('/:entity', entity, async (req, res, next) => {
  try {
    const selection = req.params.entity === 'users'
      ? 'user_id, email, display_name, is_admin, is_active, created_at, updated_at'
      : '*';
    const { rows } = await db.query(`SELECT ${selection} FROM ${req.params.entity} ORDER BY ${req.entity.pk.join(', ')} LIMIT 250`);
    res.render('admin/list', { title: req.entity.label, entityName: req.params.entity, definition: req.entity, rows });
  } catch (error) { next(error); }
});
router.get('/:entity/nuevo', entity, (req, res) => res.render('admin/form', { title: `Nuevo · ${req.entity.label}`, entityName: req.params.entity, definition: req.entity, row: {}, editing: false }));
router.post('/:entity', entity, upload.single('image_file'), async (req, res, next) => {
  try {
    const values = valuesFromBody(req.entity, req.body);
    if (req.params.entity === 'users') {
      if (String(values.password || '').length < 8) {
        req.session.flash = { type: 'error', message: 'La contraseña debe tener al menos 8 caracteres.' };
        return res.redirect('/admin/users/nuevo');
      }
      values.password_hash = await bcrypt.hash(String(values.password || ''), 12);
      delete values.password;
    }
    if (req.params.entity === 'book_images' && req.file) values.image_url = `/uploads/${req.file.filename}`;
    const columns = Object.keys(values);
    await db.query(`INSERT INTO ${req.params.entity} (${columns.join(',')}) VALUES (${columns.map((_, i) => `$${i + 1}`).join(',')})`, Object.values(values));
    req.session.flash = { type: 'success', message: 'Registro creado.' };
    res.redirect(`/admin/${req.params.entity}`);
  } catch (error) { next(error); }
});
router.get('/:entity/:keys/editar', entity, async (req, res, next) => {
  try {
    const keys = req.params.keys.split(',');
    const where = req.entity.pk.map((key, i) => `${key}=$${i + 1}`).join(' AND ');
    const selection = req.params.entity === 'users'
      ? 'user_id, email, display_name, is_admin, is_active, created_at, updated_at'
      : '*';
    const { rows } = await db.query(`SELECT ${selection} FROM ${req.params.entity} WHERE ${where}`, keys);
    if (!rows[0]) return res.status(404).render('errors/error', { title: 'No encontrado', status: 404, message: 'El registro no existe.' });
    res.render('admin/form', { title: `Editar · ${req.entity.label}`, entityName: req.params.entity, definition: req.entity, row: rows[0], editing: true });
  } catch (error) { next(error); }
});
router.put('/:entity/:keys', entity, upload.single('image_file'), async (req, res, next) => {
  try {
    const keys = req.params.keys.split(',');
    const values = valuesFromBody(req.entity, req.body);
    if (req.params.entity === 'users') {
      if (values.password) values.password_hash = await bcrypt.hash(String(values.password), 12);
      delete values.password;
    }
    if (req.params.entity === 'book_images' && req.file) values.image_url = `/uploads/${req.file.filename}`;
    req.entity.pk.forEach((key) => delete values[key]);
    const columns = Object.keys(values);
    const set = columns.map((key, i) => `${key}=$${i + 1}`).join(', ');
    const where = req.entity.pk.map((key, i) => `${key}=$${columns.length + i + 1}`).join(' AND ');
    await db.query(`UPDATE ${req.params.entity} SET ${set} WHERE ${where}`, [...Object.values(values), ...keys]);
    req.session.flash = { type: 'success', message: 'Registro actualizado.' };
    res.redirect(`/admin/${req.params.entity}`);
  } catch (error) { next(error); }
});
router.delete('/:entity/:keys', entity, async (req, res, next) => {
  try {
    const keys = req.params.keys.split(',');
    const where = req.entity.pk.map((key, i) => `${key}=$${i + 1}`).join(' AND ');
    await db.query(`DELETE FROM ${req.params.entity} WHERE ${where}`, keys);
    req.session.flash = { type: 'success', message: 'Registro eliminado.' };
    res.redirect(`/admin/${req.params.entity}`);
  } catch (error) { next(error); }
});

module.exports = router;
