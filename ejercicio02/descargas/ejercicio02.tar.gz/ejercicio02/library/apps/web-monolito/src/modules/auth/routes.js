const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../../config/database');

const router = express.Router();

router.get('/registrarse', (req, res) => res.render('auth/register', { title: 'Crear cuenta' }));
router.post('/registrarse', async (req, res, next) => {
  try {
    const email = String(req.body.email || '').trim().toLowerCase();
    const displayName = String(req.body.display_name || '').trim();
    if (!email || !displayName || String(req.body.password || '').length < 8) {
      req.session.flash = { type: 'error', message: 'Completa los datos y usa una contraseña de al menos 8 caracteres.' };
      return res.redirect('/registrarse');
    }
    const passwordHash = await bcrypt.hash(req.body.password, 12);
    const { rows } = await db.query(
      'INSERT INTO users (email, password_hash, display_name) VALUES ($1, $2, $3) RETURNING user_id, email, display_name, is_admin',
      [email, passwordHash, displayName]
    );
    req.session.regenerate((error) => {
      if (error) return next(error);
      req.session.user = rows[0];
      req.session.flash = { type: 'success', message: 'Tu cuenta está lista.' };
      res.redirect('/');
    });
  } catch (error) {
    if (error.code === '23505') {
      req.session.flash = { type: 'error', message: 'Ese correo ya está registrado.' };
      return res.redirect('/registrarse');
    }
    next(error);
  }
});

router.get('/ingresar', (req, res) => res.render('auth/login', { title: 'Ingresar' }));
router.post('/ingresar', async (req, res, next) => {
  try {
    const { rows } = await db.query('SELECT * FROM users WHERE lower(email) = lower($1) AND is_active', [String(req.body.email || '').trim()]);
    const user = rows[0];
    if (!user || !(await bcrypt.compare(String(req.body.password || ''), user.password_hash))) {
      req.session.flash = { type: 'error', message: 'Correo o contraseña incorrectos.' };
      return res.redirect('/ingresar');
    }
    const returnTo = req.session.returnTo || '/';
    req.session.regenerate((error) => {
      if (error) return next(error);
      req.session.user = { user_id: user.user_id, email: user.email, display_name: user.display_name, is_admin: user.is_admin };
      res.redirect(returnTo);
    });
  } catch (error) { next(error); }
});

router.post('/salir', (req, res, next) => req.session.destroy((error) => error ? next(error) : res.redirect('/')));
module.exports = router;
