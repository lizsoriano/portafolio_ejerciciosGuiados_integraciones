const express = require('express');
const db = require('../../config/database');
const router = express.Router();

router.get('/', async (req, res, next) => {
  try {
    const q = String(req.query.q || '').trim();
    const params = q ? [`%${q}%`] : [];
    const where = q ? 'WHERE b.title ILIKE $1 OR b.isbn ILIKE $1 OR EXISTS (SELECT 1 FROM book_authors ba2 JOIN authors a2 USING(author_id) WHERE ba2.book_id=b.book_id AND concat_ws(\' \',a2.first_name,a2.last_name) ILIKE $1)' : '';
    const { rows } = await db.query(`
      SELECT b.*, f.name format_name, c.name category_name,
        string_agg(DISTINCT concat_ws(' ',a.first_name,a.last_name), ', ') authors,
        (array_agg(i.image_url ORDER BY i.is_cover DESC, i.display_order) FILTER (WHERE i.image_id IS NOT NULL))[1] cover
      FROM books b JOIN formats f USING(format_id) JOIN categories c USING(category_id)
      LEFT JOIN book_authors ba USING(book_id) LEFT JOIN authors a USING(author_id)
      LEFT JOIN book_images i USING(book_id) ${where}
      GROUP BY b.book_id, f.name, c.name ORDER BY b.created_at DESC`, params);
    res.render('catalog/index', { title: 'Catálogo', books: rows, q });
  } catch (error) { next(error); }
});

router.get('/libros/:id', async (req, res, next) => {
  try {
    const [book, authors, genres, images, concepts] = await Promise.all([
      db.query('SELECT b.*, f.name format_name, c.name category_name FROM books b JOIN formats f USING(format_id) JOIN categories c USING(category_id) WHERE book_id=$1', [req.params.id]),
      db.query('SELECT a.* FROM authors a JOIN book_authors ba USING(author_id) WHERE ba.book_id=$1 ORDER BY ba.author_order', [req.params.id]),
      db.query('SELECT g.* FROM genres g JOIN book_genres bg USING(genre_id) WHERE bg.book_id=$1 ORDER BY g.name', [req.params.id]),
      db.query('SELECT * FROM book_images WHERE book_id=$1 ORDER BY is_cover DESC, display_order', [req.params.id]),
      db.query('SELECT c.name, bc.definition FROM concepts c JOIN book_concepts bc USING(concept_id) WHERE bc.book_id=$1 ORDER BY c.name', [req.params.id]),
    ]);
    if (!book.rows[0]) return res.status(404).render('errors/error', { title: 'Libro no encontrado', status: 404, message: 'El libro solicitado no existe.' });
    res.render('catalog/detail', { title: book.rows[0].title, book: book.rows[0], authors: authors.rows, genres: genres.rows, images: images.rows, concepts: concepts.rows });
  } catch (error) { next(error); }
});

module.exports = router;
