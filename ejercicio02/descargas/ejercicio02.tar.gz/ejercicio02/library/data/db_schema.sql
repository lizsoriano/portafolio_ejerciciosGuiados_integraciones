-- Punto de entrada solicitado para el esquema de la aplicación.
-- psql resuelve \ir con respecto a la ubicación de este archivo.
\ir ../db/schema.sql
